import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Set style
sns.set_style("whitegrid")
plt.rcParams['figure.figsize'] = (12, 6)

# ====== 1. CHARGING STATIONS ANALYSIS ======
charging_data = {
    'State/UT': ['Karnataka', 'Maharashtra', 'Uttar Pradesh', 'Delhi', 'Tamil Nadu', 
                'Kerala', 'Rajasthan', 'Gujarat', 'Haryana', 'Madhya Pradesh', 'Chhattisgarh'],
    'Public Charging Stations (PCS)': [5765, 3728, 1989, 1941, 1413, 958, 500, 476, 377, 341, 271]
}
charging_df = pd.DataFrame(charging_data).sort_values('Public Charging Stations (PCS)', ascending=False)

# Plot charging stations distribution
plt.figure(figsize=(14, 7))
ax = sns.barplot(x='State/UT', y='Public Charging Stations (PCS)', data=charging_df, palette='viridis')
plt.title('Public Charging Stations Distribution by State', fontsize=16)
plt.xticks(rotation=45, ha='right')
plt.ylabel('Number of Stations')
plt.xlabel('State/UT')

# Add value labels
for p in ax.patches:
    ax.annotate(f'{int(p.get_height()):,}', 
                (p.get_x() + p.get_width() / 2., p.get_height()),
                ha='center', va='center', xytext=(0, 10), textcoords='offset points')
plt.tight_layout()
plt.show()
