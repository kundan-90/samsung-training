import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

# Create DataFrame from provided data
data = {
    'Vehicle Type': ['Standard Gasoline Vehicle', 'Hybrid Vehicle', 'Battery Electric Vehicle'],
    'Lifecycle Emissions': [24, 21, 19],
    'Production Emissions': [5.6, 6.5, 8.8],
    'Production Proportion': [23, 31, 46]
}

df = pd.DataFrame(data)

# Calculate use phase emissions
df['Use Phase Emissions'] = df['Lifecycle Emissions'] - df['Production Emissions']

# Calculate emission savings compared to gasoline vehicle
df['Emission Savings'] = df['Lifecycle Emissions'].iloc[0] - df['Lifecycle Emissions']

# Calculate percentage breakdown
df['Production %'] = (df['Production Emissions'] / df['Lifecycle Emissions']) * 100
df['Use Phase %'] = (df['Use Phase Emissions'] / df['Lifecycle Emissions']) * 100

plt.figure(figsize=(10, 6))
barplot = sns.barplot(
    data=df,
    x='Vehicle Type',
    y='Lifecycle Emissions',
    palette=['#E74C3C', '#F39C12', '#2ECC71']
)

plt.title('Total Lifecycle CO₂ Emissions by Vehicle Type', fontsize=15, pad=15)
plt.ylabel('Tonnes CO₂e')
plt.xlabel('')
plt.ylim(0, 26)

# Add value labels
for p in barplot.patches:
    barplot.annotate(
        f'{p.get_height():.1f}',
        (p.get_x() + p.get_width()/2., p.get_height()),
        ha='center', va='center', xytext=(0, 7), textcoords='offset points'
    )

# Add emission savings annotation
plt.text(0.5, 24.5, 'Baseline', ha='center', fontsize=9)
plt.text(1.5, 21.5, '3.0 tonnes saved', ha='center', fontsize=9, color='green')
plt.text(2.5, 19.5, '5.0 tonnes saved', ha='center', fontsize=9, color='green')

plt.tight_layout()
plt.savefig('lifecycle_emissions.png', dpi=300)
plt.show()

plt.figure(figsize=(10, 6))

# Plot use phase emissions (bottom)
use_bars = plt.bar(
    df['Vehicle Type'],
    df['Use Phase Emissions'],
    color=['#3498DB', '#3498DB', '#3498DB'],
    label='Use Phase'
)

# Plot production emissions on top
prod_bars = plt.bar(
    df['Vehicle Type'],
    df['Production Emissions'],
    bottom=df['Use Phase Emissions'],
    color=['#E67E22', '#E67E22', '#E67E22'],
    label='Production'
)

plt.title('Emissions Breakdown by Lifecycle Phase', fontsize=15, pad=15)
plt.ylabel('Tonnes CO₂e')
plt.legend(loc='upper right')

# Add percentage labels
for i, vehicle in enumerate(df['Vehicle Type']):
    total = df.loc[i, 'Lifecycle Emissions']
    prod = df.loc[i, 'Production Emissions']
    use = df.loc[i, 'Use Phase Emissions']
    
    plt.text(i, use/2, f'Use: {use:.1f}t\n({df.loc[i, "Use Phase %"]:.0f}%)', 
             ha='center', va='center', color='white', fontsize=9)
    plt.text(i, use + prod/2, f'Prod: {prod:.1f}t\n({df.loc[i, "Production %"]:.0f}%)', 
             ha='center', va='center', color='white', fontsize=9)

plt.tight_layout()
plt.savefig('emissions_breakdown.png', dpi=300)
plt.show()

plt.figure(figsize=(10, 6))
barplot = sns.barplot(
    data=df,
    x='Vehicle Type',
    y='Production Emissions',
    palette=['#E74C3C', '#F39C12', '#2ECC71']
)

plt.title('Manufacturing Emissions Comparison', fontsize=15, pad=15)
plt.ylabel('Tonnes CO₂e')
plt.xlabel('')
plt.ylim(0, 10)

# Add value labels and change annotations
for i, p in enumerate(barplot.patches):
    height = p.get_height()
    barplot.annotate(
        f'{height:.1f}',
        (p.get_x() + p.get_width()/2., height),
        ha='center', va='center', xytext=(0, 7), textcoords='offset points'
    )
    
    # Add comparative annotations
    if i == 0:
        barplot.annotate(
            'Baseline',
            (p.get_x() + p.get_width()/2., height),
            ha='center', va='center', xytext=(0, -20), textcoords='offset points'
        )
    else:
        diff = height - df.loc[0, 'Production Emissions']
        barplot.annotate(
            f'+{diff:.1f}t',
            (p.get_x() + p.get_width()/2., height),
            ha='center', va='center', xytext=(0, -20), textcoords='offset points',
            color='red' if diff > 0 else 'green'
        )

plt.tight_layout()
plt.savefig('production_emissions.png', dpi=300)
plt.show()

fig, axes = plt.subplots(1, 3, figsize=(18, 6))
fig.suptitle('Emissions Distribution Across Lifecycle Phases', fontsize=16)

colors = ['#E67E22', '#3498DB']  # Production, Use Phase

for i, row in df.iterrows():
    sizes = [row['Production Emissions'], row['Use Phase Emissions']]
    labels = ['Production', 'Use Phase']
    
    axes[i].pie(
        sizes,
        labels=labels,
        autopct='%1.1f%%',
        startangle=90,
        colors=colors,
        wedgeprops={'edgecolor': 'w', 'linewidth': 2}
    )
    axes[i].set_title(f"{row['Vehicle Type']}\nTotal: {row['Lifecycle Emissions']}t CO₂e", fontsize=13)

plt.tight_layout(rect=[0, 0, 1, 0.95])
plt.savefig('emissions_proportion.png', dpi=300)
plt.show()

