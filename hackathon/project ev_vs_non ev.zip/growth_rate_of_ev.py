import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

# Create DataFrame from provided data
data = {
    'State/UT': ['Uttar Pradesh', 'Tamil Nadu', 'Madhya Pradesh', 'Maharashtra', 
                 'Karnataka', 'Bihar', 'Rajasthan', 'Mizoram'],
    'EV Units FY23‑24': ['~78,744', '~96,000', '~78,744', '–', '–', '–', '–', '–'],
    'EV Units FY24‑25': ['~107,258', '~131,482', '~107,258', '241,941', 
                         '179,037', '112,854', '109,393', '–'],
    'Growth Rate (%)': ['36.2%', '35.9%', '36.2%', '– (volume only)', 
                        '– (volume only)', '– (volume only)', '– (volume only)', '139% Y-o-Y (highest)']
}

df = pd.DataFrame(data)

# Clean numerical columns
def clean_num(x):
    if isinstance(x, str):
        x = x.replace('~', '').replace(',', '').replace('%', '')
        if any(char.isdigit() for char in x):
            return float(''.join(filter(lambda y: y.isdigit() or y == '.', x)))
    return np.nan

df['EV Units FY23‑24'] = df['EV Units FY23‑24'].apply(clean_num)
df['EV Units FY24‑25'] = df['EV Units FY24‑25'].apply(clean_num)

# Extract growth rate numbers
df['Growth Rate'] = df['Growth Rate (%)'].str.extract(r'(\d+\.?\d*)').astype(float)

plt.figure(figsize=(12, 6))
sns.barplot(
    data=df.sort_values('EV Units FY24‑25', ascending=False).head(7),
    x='State/UT', 
    y='EV Units FY24‑25',
    palette='viridis'
)
plt.title('Top States by EV Registrations (FY 2024-25)', fontsize=14)
plt.ylabel('Number of EVs (Thousands)')
plt.ylim(0, 260000)
plt.gca().yaxis.set_major_formatter(plt.FuncFormatter(lambda x, _: f'{int(x/1000)}'))
plt.xticks(rotation=45)
plt.tight_layout()
plt.savefig('top_states_volume.png', dpi=300)
plt.show()

# Filter states with available growth rates
growth_df = df.dropna(subset=['Growth Rate']).sort_values('Growth Rate', ascending=False)

plt.figure(figsize=(10, 6))
bars = plt.bar(
    growth_df['State/UT'], 
    growth_df['Growth Rate'],
    color=['#1f77b4' if state != 'Mizoram' else '#ff7f0e' for state in growth_df['State/UT']]
)
plt.title('Y-o-Y EV Growth Rate Comparison', fontsize=14)
plt.ylabel('Growth Rate (%)')
plt.xticks(rotation=15)

# Add value labels
for bar in bars:
    height = bar.get_height()
    plt.text(bar.get_x() + bar.get_width()/2., height + 3,
             f'{height:.1f}%', ha='center', va='bottom')

plt.tight_layout()
plt.savefig('growth_rate_comparison.png', dpi=300)
plt.show()

# Select states with both years' data
compare_df = df[df['EV Units FY23‑24'].notna()].head(3).melt(
    id_vars='State/UT', 
    value_vars=['EV Units FY23‑24', 'EV Units FY24‑25'],
    var_name='Year',
    value_name='Units'
)

plt.figure(figsize=(10, 6))
sns.barplot(
    data=compare_df,
    x='State/UT',
    y='Units',
    hue='Year',
    palette='Blues'
)
plt.title('EV Registration Comparison: FY23-24 vs FY24-25', fontsize=14)
plt.ylabel('Number of EVs (Thousands)')
plt.gca().yaxis.set_major_formatter(plt.FuncFormatter(lambda x, _: f'{int(x/1000)}'))
plt.xticks(rotation=15)
plt.legend(title='Financial Year')
plt.tight_layout()
plt.savefig('yoy_comparison.png', dpi=300)
plt.show()

plt.figure(figsize=(10, 6))
sns.scatterplot(
    data=df,
    x='EV Units FY24‑25',
    y='Growth Rate',
    hue='State/UT',
    s=200,
    palette='tab10'
)
plt.title('EV Volume vs Growth Rate (FY 2024-25)', fontsize=14)
plt.xlabel('EV Registrations (Thousands)')
plt.ylabel('Growth Rate (%)')
plt.xlim(0, 260000)
plt.gca().xaxis.set_major_formatter(plt.FuncFormatter(lambda x, _: f'{int(x/1000)}'))
plt.grid(alpha=0.3)

# Add state labels
for i, row in df.iterrows():
    if not np.isnan(row['Growth Rate']):
        plt.annotate(row['State/UT'], 
                    (row['EV Units FY24‑25'] + 5000, 
                     row['Growth Rate'] + 2),
                    fontsize=9)

plt.tight_layout()
plt.savefig('volume_vs_growth.png', dpi=300)
plt.show()