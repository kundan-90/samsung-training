import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

# Create DataFrame from provided data
data = {
    'State/UT': ['Uttar Pradesh', 'Maharashtra', 'Karnataka', 'Tamil Nadu', 
                 'Gujarat', 'Delhi', 'Rajasthan', 'Andhra Pradesh', 
                 'West Bengal', 'Madhya Pradesh', 'India Total'],
    'EV Vehicles': [574967, 305006, 248747, 173152, 138410, 233212, 180670, 67905, 68376, 96151, 2086596],
    'ICE Vehicles': [43852548, 34323748, 29785247, 31618002, 22804558, 13994966, 18857703, 16553509, 15227219, 19616269, 246633769],
    'Total CO₂ by EVs (tonnes)': [287483.5, 152503, 124373.5, 86576, 69205, 116606, 90335, 33952.5, 34188, 48075.5, 1043298],
    'Total CO₂ by ICEs (tonnes)': [87705096, 68647496, 59570494, 63236004, 45609116, 27989932, 37715406, 33107018, 30454438, 39232538, 493267538]
}

df = pd.DataFrame(data)

# Remove India Total row for state-level analysis
df_states = df[df['State/UT'] != 'India Total'].copy()

# Calculate total vehicles and total CO₂
df_states['Total Vehicles'] = df_states['EV Vehicles'] + df_states['ICE Vehicles']
df_states['Total CO₂ (tonnes)'] = df_states['Total CO₂ by EVs (tonnes)'] + df_states['Total CO₂ by ICEs (tonnes)']

# Calculate EV penetration percentage
df_states['EV Penetration (%)'] = (df_states['EV Vehicles'] / df_states['Total Vehicles']) * 100

# Calculate CO₂ savings potential
df_states['CO₂ Savings Potential (tonnes)'] = df_states['ICE Vehicles'] * (2 - 0.5)  # If all ICE switched to EV

# India-level data
india_row = df[df['State/UT'] == 'India Total'].iloc[0]

# Vehicle composition pie chart
plt.figure(figsize=(12, 6))
plt.subplot(1, 2, 1)
plt.pie(
    [india_row['EV Vehicles'], india_row['ICE Vehicles']],
    labels=['EV Vehicles', 'ICE Vehicles'],
    autopct='%1.1f%%',
    colors=['#4CAF50', '#F44336'],
    startangle=90
)
plt.title('India: Vehicle Composition', fontsize=14)

# CO₂ emissions composition pie chart
plt.subplot(1, 2, 2)
plt.pie(
    [india_row['Total CO₂ by EVs (tonnes)'], india_row['Total CO₂ by ICEs (tonnes)']],
    labels=['EV Emissions', 'ICE Emissions'],
    autopct='%1.1f%%',
    colors=['#66BB6A', '#EF5350'],
    startangle=90
)
plt.title('India: CO₂ Emissions Distribution', fontsize=14)
plt.tight_layout()
plt.savefig('india_emissions_composition.png', dpi=300, bbox_inches='tight')
plt.show()

# Select top 3 states by total CO₂ emissions
top_states = df_states.nlargest(3, 'Total CO₂ (tonnes)')['State/UT'].tolist()

# Create subplots
fig, axes = plt.subplots(1, 3, figsize=(18, 6))
fig.suptitle('Vehicle Composition in Top 3 States by Emissions', fontsize=16)

for i, state in enumerate(top_states):
    state_data = df_states[df_states['State/UT'] == state].iloc[0]
    axes[i].pie(
        [state_data['EV Vehicles'], state_data['ICE Vehicles']],
        labels=['EV', 'ICE'],
        autopct='%1.1f%%',
        colors=['#4CAF50', '#F44336'],
        startangle=90
    )
    axes[i].set_title(f"{state}\nTotal Vehicles: {state_data['Total Vehicles']/1e6:.1f}M", fontsize=14)

plt.tight_layout(rect=[0, 0, 1, 0.95])
plt.savefig('top_states_vehicle_composition.png', dpi=300, bbox_inches='tight')
plt.show()

# Prepare data for stacked bar chart
df_states_sorted = df_states.sort_values('Total CO₂ (tonnes)', ascending=False)

# Create stacked bar chart
plt.figure(figsize=(14, 8))
bar_width = 0.8

# Plot ICE emissions (bottom)
ice_bars = plt.bar(
    df_states_sorted['State/UT'],
    df_states_sorted['Total CO₂ by ICEs (tonnes)'],
    color='#EF5350',
    label='ICE Emissions',
    width=bar_width
)

# Plot EV emissions on top of ICE
ev_bars = plt.bar(
    df_states_sorted['State/UT'],
    df_states_sorted['Total CO₂ by EVs (tonnes)'],
    bottom=df_states_sorted['Total CO₂ by ICEs (tonnes)'],
    color='#66BB6A',
    label='EV Emissions',
    width=bar_width
)

plt.title('State-wise CO₂ Emissions from Vehicles', fontsize=16)
plt.ylabel('CO₂ Emissions (Million Tonnes)')
plt.yscale('log')
plt.xticks(rotation=45, ha='right')
plt.legend()
plt.grid(axis='y', alpha=0.3)

# Format y-axis labels
plt.gca().yaxis.set_major_formatter(plt.FuncFormatter(lambda x, _: f'{x/1e6:.0f}M'))

plt.tight_layout()
plt.savefig('state_emissions_comparison.png', dpi=300, bbox_inches='tight')
plt.show()

plt.figure(figsize=(12, 8))
scatter = sns.scatterplot(
    data=df_states,
    x='EV Penetration (%)',
    y='Total CO₂ (tonnes)',
    size='Total Vehicles',
    sizes=(100, 1000),
    hue='State/UT',
    palette='tab10',
    legend='brief'
)

plt.title('EV Penetration vs Total CO₂ Emissions', fontsize=16)
plt.xlabel('EV Penetration (%)')
plt.ylabel('Total CO₂ Emissions (Million Tonnes)')
plt.ylim(0, 1e8)
plt.gca().yaxis.set_major_formatter(plt.FuncFormatter(lambda x, _: f'{x/1e6:.0f}M'))
plt.grid(alpha=0.3)

# Add state labels
for i, row in df_states.iterrows():
    plt.annotate(row['State/UT'], 
                (row['EV Penetration (%)'] + 0.05, 
                 row['Total CO₂ (tonnes)'] + 5e5),
                fontsize=9)

plt.tight_layout()
plt.savefig('ev_penetration_vs_emissions.png', dpi=300, bbox_inches='tight')
plt.show()

# Calculate potential savings
df_states['CO₂ Savings Potential (M tonnes)'] = df_states['CO₂ Savings Potential (tonnes)'] / 1e6
df_sorted_savings = df_states.sort_values('CO₂ Savings Potential (M tonnes)', ascending=False)

# Create horizontal bar chart
plt.figure(figsize=(12, 8))
bars = plt.barh(
    df_sorted_savings['State/UT'],
    df_sorted_savings['CO₂ Savings Potential (M tonnes)'],
    color='#29B6F6'
)

plt.title('Potential CO₂ Savings from Full EV Transition', fontsize=16)
plt.xlabel('Potential CO₂ Savings (Million Tonnes)')
plt.ylabel('State/UT')
plt.xlim(0, 70)

# Add value labels
for bar in bars:
    width = bar.get_width()
    plt.text(width + 1, bar.get_y() + bar.get_height()/2, 
             f'{width:.1f}M', 
             va='center', ha='left')

plt.tight_layout()
plt.savefig('co2_savings_potential.png', dpi=300, bbox_inches='tight')
plt.show()

